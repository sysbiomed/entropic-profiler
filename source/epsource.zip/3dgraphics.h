/*****************/
/** 3D GRAPHICS **/
/*****************/

void initialize3DGraphics(int w, int h);

void drawPlot3D(double **points, int xnp, int ynp, int xstart);

void draw3DLabel(int maxi, int maxl);
